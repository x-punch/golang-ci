// This file's only purpose is to provide a realistic
// environment from which to run integration tests
// against the Watcher.
package main

import "fmt"

func main() {
	fmt.Println("Hello, World!")
}
