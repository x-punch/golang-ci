# logger
基于标准库增加上下文等信息的logger

> Required Go1.8+
