# config
项目的日志解析库封装，目前支持 ini
