# Bot Plugins

The micro bot is pluggable via Inputs and Commands. Read more about the bot in the blog post 
[micro.mu/blog/2016/04/25/the-micro-bot.html](https://micro.mu/blog/2016/04/25/the-micro-bot.html).

Learn more about the bot plugins at [github.com/micro/micro/bot](https://github.com/micro/micro/tree/master/bot).
