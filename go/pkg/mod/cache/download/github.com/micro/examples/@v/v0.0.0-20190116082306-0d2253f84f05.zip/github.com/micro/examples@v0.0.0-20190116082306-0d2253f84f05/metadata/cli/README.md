# Metadata Client

This directory contains the client example for setting metadata and sending to a service

## Contents

- main.go - standard go-micro client call

