# Flags

This is an example of using command line flags

## Run the example

```shell
go run main.go --string_flag="a string" --int_flag=10 --bool_flag=true
```

And that's all there is to it.
