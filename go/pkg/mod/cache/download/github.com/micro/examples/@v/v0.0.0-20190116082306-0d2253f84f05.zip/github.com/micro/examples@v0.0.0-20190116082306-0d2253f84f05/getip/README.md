# Get IP

The GetIP example demonstrates how to get local and remote ips from metadata.

