# Filter

Filter demonstrates how to filter requests in the client

## Usage

```
// Run the service example
go run ../service/main.go
```

```
// Run the client
go run main.go
```
