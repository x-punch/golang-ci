# Wrapper

This is an example of how to use wrappers, a form of middleware

- main.go - the service with a log handler wrapper
- cli/main.go - the client with a log client wrapper
