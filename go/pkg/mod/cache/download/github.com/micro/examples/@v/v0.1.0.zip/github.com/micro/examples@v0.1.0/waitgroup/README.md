# Waitgroup

This demonstrates how to use sync.WaitGroup with a service.

