# Command

This is an example of a bot command as a microservice

## Contents

- main.go - is the main definition of the service and handler

## Run the example

Run the service

```shell
go run main.go
```

## Call the service

Run the [bot](https://micro.mu/docs/bot.html) and send message `command`
