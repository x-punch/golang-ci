package main

import (
	_ "github.com/micro/go-plugins/registry/etcd"
)
