# Graceful

Graceful demonstrates graceful shutdown of a service using the server.Wait option

The server deregisters the service and waits for handlers to finish executing before exiting.

