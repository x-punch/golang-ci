# Examples

Name	|	Description
---	|	---
[Message](https://github.com/micro/message-web)	|	A simple text based messaging web app
[Geo](https://github.com/micro/geo-web)	|	A geo location map demo

