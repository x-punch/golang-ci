# client

[Run the service first](../service)

Then, compile + run:

```
go build
./client
```

Check out other services:

```
./client <service-tag>
./client _foobarbaz._tcp
```
