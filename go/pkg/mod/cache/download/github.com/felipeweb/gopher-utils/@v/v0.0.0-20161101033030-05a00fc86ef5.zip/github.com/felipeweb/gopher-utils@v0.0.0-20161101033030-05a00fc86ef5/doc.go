//commonly used functions for the Go programming language.
package gopher_utils