# gopher-utils 

[![Build Status](https://travis-ci.org/felipeweb/gopher-utils.svg?branch=master)](https://travis-ci.org/felipeweb/gopher-utils) [![GoDoc](https://godoc.org/github.com/felipeweb/gopher-utils?status.svg)](https://godoc.org/github.com/felipeweb/gopher-utils)

This is an open source project for commonly used functions for the Go programming language.
