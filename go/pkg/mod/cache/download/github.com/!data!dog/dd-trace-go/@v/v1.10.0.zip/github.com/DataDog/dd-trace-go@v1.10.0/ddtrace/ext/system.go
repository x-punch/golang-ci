package ext

// Standard system metadata names
const (
	// The pid of the traced process
	Pid = "system.pid"
)
