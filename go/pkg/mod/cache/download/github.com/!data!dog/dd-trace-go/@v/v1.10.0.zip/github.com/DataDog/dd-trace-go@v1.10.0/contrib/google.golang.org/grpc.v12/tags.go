package grpc

// Tags used for gRPC
const (
	tagMethod = "grpc.method"
	tagCode   = "grpc.code"
)
