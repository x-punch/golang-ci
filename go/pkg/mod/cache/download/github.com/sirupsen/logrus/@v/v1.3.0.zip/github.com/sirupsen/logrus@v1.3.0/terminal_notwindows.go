// +build !windows

package logrus

import "io"

func initTerminal(w io.Writer) {
}
