// Package jose implements some helper functions and types for the children
// packages, jws, jwt, and jwe.
package jose
