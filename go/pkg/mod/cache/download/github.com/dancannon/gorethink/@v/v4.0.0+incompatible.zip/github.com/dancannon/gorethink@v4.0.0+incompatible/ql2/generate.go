//go:generate protoc --go_out=. ql2.proto

package ql2
