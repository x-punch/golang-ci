---
name: Disclose vulnerability
about: Please do not open a public issue about the vulnerability but instead disclose it directly to hi@ory.sh

---

Please refrain from publishing (potential) security vulnerabilities publicly on the forums, the chat, or GitHub. Instead,
send us an email to [hi@ory.sh](mailto:hi@ory.sh) and we will respond within 24 hours.
