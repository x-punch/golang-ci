## cmd

This directory is meant to enforce vendoring for etcd binaries without polluting
the etcd client libraries with vendored dependencies.
