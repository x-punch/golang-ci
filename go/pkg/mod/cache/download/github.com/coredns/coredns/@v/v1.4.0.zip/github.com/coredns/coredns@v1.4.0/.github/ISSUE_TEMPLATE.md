<!-- 
When reporting bugs and requesting assistance, please include:
* the version of CoreDNS you are using
* your Corefile
* logs, if applicable

Thanks for using CoreDNS!
-->
