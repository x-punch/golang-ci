package coremain

// Various CoreDNS constants.
const (
	CoreVersion = "1.3.1"
	coreName    = "CoreDNS"
	serverType  = "dns"
)
