// Package test contains helper functions for writing plugin tests.
package test
