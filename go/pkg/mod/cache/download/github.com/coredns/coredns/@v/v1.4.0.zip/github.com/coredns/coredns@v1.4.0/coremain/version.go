package coremain

// Various CoreDNS constants.
const (
	CoreVersion = "1.4.0"
	coreName    = "CoreDNS"
	serverType  = "dns"
)
