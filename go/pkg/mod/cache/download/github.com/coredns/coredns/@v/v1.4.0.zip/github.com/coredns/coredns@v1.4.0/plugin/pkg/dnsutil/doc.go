// Package dnsutil contains DNS related helper functions.
package dnsutil
