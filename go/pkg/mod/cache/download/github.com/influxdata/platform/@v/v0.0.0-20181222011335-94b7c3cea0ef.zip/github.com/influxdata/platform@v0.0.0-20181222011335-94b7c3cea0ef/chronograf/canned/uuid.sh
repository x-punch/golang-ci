#!/bin/sh
uuidgen | tr A-Z a-z
