**We've moved our documentation!** Check our latest [guides](https://docs.influxdata.com/chronograf/latest/guides/) on InfluxData's [main docs site](https://docs.influxdata.com/chronograf/latest/).
