## Canned Applications
The JSON application layouts in this directory ship with the application as nice, default layouts and queries for telegraf data.

### Create new Application

To create a new application in this directory run `./new_apps.sh`.  This shell script will create a new application template with a generated UUID.
Update this layout application file's queries, measurements, and application name.
