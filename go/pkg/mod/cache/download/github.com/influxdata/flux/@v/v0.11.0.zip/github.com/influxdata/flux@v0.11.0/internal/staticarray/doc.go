// Package staticarray defines implementations of flux arrays with static data.
// It does not support null values.
package staticarray
