package main

import "github.com/influxdata/flux/cmd/changelog/cmd"

func main() {
	cmd.Execute()
}
