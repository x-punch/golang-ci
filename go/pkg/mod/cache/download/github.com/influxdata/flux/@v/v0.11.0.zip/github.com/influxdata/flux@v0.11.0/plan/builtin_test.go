package plan_test

import (
	// We need to import the builtins for the tests to work.
	_ "github.com/influxdata/flux/builtin"
)
