package execute

type Window struct {
	Every  Duration
	Period Duration
	Round  Duration
	Start  Time
}
