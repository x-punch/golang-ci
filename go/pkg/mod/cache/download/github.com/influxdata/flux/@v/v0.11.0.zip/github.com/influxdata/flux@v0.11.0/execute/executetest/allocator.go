package executetest

import (
	"github.com/influxdata/flux/memory"
)

var UnlimitedAllocator = &memory.Allocator{}
