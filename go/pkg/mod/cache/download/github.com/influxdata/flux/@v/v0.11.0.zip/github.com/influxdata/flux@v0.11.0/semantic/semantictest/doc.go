// Package semantictest contains utilities for testing the semantic package.
package semantictest
