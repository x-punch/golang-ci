package influxql // import "github.com/influxdata/influxql"

//go:generate protoc --gogo_out=. internal/internal.proto
