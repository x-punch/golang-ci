# compiler

[Read the docs.](https://godoc.org/github.com/ory-am/common/compiler)