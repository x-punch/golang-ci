/*
Package client implements client connectivity in the STOMP server.

The key abstractions include a connection, a subscription and
a client request.
*/
package client
