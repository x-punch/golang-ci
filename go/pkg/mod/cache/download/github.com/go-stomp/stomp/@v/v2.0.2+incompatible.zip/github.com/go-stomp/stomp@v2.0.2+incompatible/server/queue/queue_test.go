package queue

import (
	"gopkg.in/check.v1"
	"testing"
)

// Runs all gocheck tests in this package.
// See other *_test.go files for gocheck tests.
func TestQueue(t *testing.T) {
	check.TestingT(t)
}
