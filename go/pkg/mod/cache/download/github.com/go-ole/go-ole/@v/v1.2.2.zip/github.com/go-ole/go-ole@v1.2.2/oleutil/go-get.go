// This file is here so go get succeeds as without it errors with:
// no buildable Go source files in ...
//
// +build !windows

package oleutil
