# gosimple

_gosimple_ is a linter for Go source code that specialises on
simplifying code.

## Installation

Gosimple requires Go 1.6 or later.

    go get honnef.co/go/tools/cmd/gosimple

## Documentation

Detailed documentation can be found on
[staticcheck.io](https://staticcheck.io/docs/gosimple).
