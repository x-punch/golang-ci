# errcheck-ng

_errcheck-ng_ is the next generation of errcheck.

## Installation

    go get honnef.co/go/tools/cmd/errcheck-ng

## Usage

TODO

## Purpose

TODO

