//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc2869 -output generated.go /usr/share/freeradius/dictionary.rfc2869

package rfc2869
